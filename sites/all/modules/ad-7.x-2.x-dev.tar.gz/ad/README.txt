Documentation can be found in the documentation/ subdirectory.
